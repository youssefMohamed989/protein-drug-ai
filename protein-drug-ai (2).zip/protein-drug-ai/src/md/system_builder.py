"""Build an OpenMM System from a receptor PDB, using the Amber14 force field.

Defaults to implicit solvent (GBn2) since it needs no box-padding/
equilibration dance and runs fast enough for CPU-only environments; explicit
TIP3P solvation is offered for production-quality runs when a GPU/cluster is
available.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional, Tuple


@dataclass
class SystemBuildResult:
    topology: object  # openmm.app.Topology
    system: object  # openmm.System
    positions: object  # openmm quantity, (n_atoms, 3)


def build_system(
    fixed_pdb_path: str,
    solvent: str = "implicit",  # "implicit" | "explicit" | "vacuum"
    implicit_model: str = "implicit/gbn2.xml",
    padding_nm: float = 1.0,
    ionic_strength_molar: float = 0.15,
    nonbonded_cutoff_nm: float = 1.0,
    constrain_hbonds: bool = True,
) -> SystemBuildResult:
    from openmm import unit
    from openmm.app import (
        PME,
        ForceField,
        HBonds,
        Modeller,
        NoCutoff,
        PDBFile,
    )

    pdb = PDBFile(fixed_pdb_path)
    modeller = Modeller(pdb.topology, pdb.positions)

    constraints = HBonds if constrain_hbonds else None

    if solvent == "vacuum":
        forcefield = ForceField("amber14-all.xml")
        system = forcefield.createSystem(
            modeller.topology,
            nonbondedMethod=NoCutoff,
            constraints=constraints,
        )
    elif solvent == "implicit":
        forcefield = ForceField("amber14-all.xml", implicit_model)
        system = forcefield.createSystem(
            modeller.topology,
            nonbondedMethod=NoCutoff,
            constraints=constraints,
        )
    elif solvent == "explicit":
        forcefield = ForceField("amber14-all.xml", "amber14/tip3p.xml")
        modeller.addSolvent(
            forcefield,
            padding=padding_nm * unit.nanometer,
            ionicStrength=ionic_strength_molar * unit.molar,
        )
        system = forcefield.createSystem(
            modeller.topology,
            nonbondedMethod=PME,
            nonbondedCutoff=nonbonded_cutoff_nm * unit.nanometer,
            constraints=constraints,
        )
    else:
        raise ValueError(f"Unknown solvent mode '{solvent}'")

    return SystemBuildResult(topology=modeller.topology, system=system, positions=modeller.positions)
