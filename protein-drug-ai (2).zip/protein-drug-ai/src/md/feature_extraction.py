"""Turn an MD trajectory into features the rest of this repo already knows
how to consume — most importantly, a time-averaged contact map in exactly
the format `ProteinStructureDataset` expects (see docs/data_schema.md),
so an MD run on a predicted structure can generate *real* physics-derived
training labels to fine-tune the structure-prediction model on, closing the
loop: predict -> refine with MD -> re-train on MD-derived labels.
"""

from __future__ import annotations

from typing import Dict, Optional

import numpy as np


def time_averaged_contact_map(
    topology_pdb: str,
    trajectory_dcd: str,
    threshold_nm: float = 0.8,
    frame_stride: int = 1,
) -> np.ndarray:
    """Fraction-of-frames-in-contact matrix (L, L) in [0, 1] — the natural
    MD-ensemble generalization of the single-structure binary contact map
    used elsewhere in this repo (threshold defaults to 8A, matching
    src/data/protein_features.contact_map_from_coords).
    """
    import mdtraj as md

    traj = md.load(trajectory_dcd, top=topology_pdb)[::frame_stride]
    traj = traj.atom_slice(traj.topology.select("protein and name CA"))

    n_frames, n_residues, _ = traj.xyz.shape
    fraction_in_contact = np.zeros((n_residues, n_residues), dtype=np.float32)

    for frame in traj.xyz:
        diff = frame[:, None, :] - frame[None, :, :]
        dist = np.sqrt((diff**2).sum(-1))
        fraction_in_contact += (dist <= threshold_nm).astype(np.float32)

    fraction_in_contact /= n_frames
    np.fill_diagonal(fraction_in_contact, 0.0)
    return fraction_in_contact


def contact_map_to_csv_field(contact_map: np.ndarray, binarize_threshold: float = 0.5) -> str:
    """Serialize a contact map to the ';'-joined row-major string format
    used by data/processed/*structure*.csv (see src/data/datasets.py).
    """
    binary = (contact_map >= binarize_threshold).astype(np.int32)
    return ";".join(str(int(v)) for v in binary.flatten())


def per_residue_flexibility_features(topology_pdb: str, trajectory_dcd: str) -> Dict[str, np.ndarray]:
    """Per-residue RMSF and mean solvent-accessible surface area (SASA),
    two standard structural-flexibility features useful as auxiliary
    training signals or as extra input features for downstream affinity
    models (flexible pockets often correlate with promiscuous binding).
    """
    import mdtraj as md

    traj = md.load(trajectory_dcd, top=topology_pdb)
    traj_protein = traj.atom_slice(traj.topology.select("protein"))
    ca_indices = traj_protein.topology.select("name CA")

    traj_protein.superpose(traj_protein, atom_indices=ca_indices, frame=0)
    rmsf = md.rmsf(traj_protein, traj_protein, frame=0, atom_indices=ca_indices)

    try:
        sasa_per_atom = md.shrake_rupley(traj_protein, mode="residue")
        mean_sasa = sasa_per_atom.mean(axis=0)
    except Exception:
        mean_sasa = np.full(len(ca_indices), np.nan)

    return {"rmsf_nm": rmsf, "mean_sasa_nm2": mean_sasa}


def extract_representative_frame(
    topology_pdb: str,
    trajectory_dcd: str,
    out_pdb: str,
    method: str = "medoid",
) -> str:
    """Pick one representative conformation from the trajectory (the frame
    closest, in CA-RMSD, to the ensemble mean structure) — a cheap
    alternative to full clustering, useful for downstream docking against
    a "typical" rather than a single arbitrarily-chosen frame.
    """
    import mdtraj as md

    traj = md.load(trajectory_dcd, top=topology_pdb)
    traj_protein = traj.atom_slice(traj.topology.select("protein"))
    ca_indices = traj_protein.topology.select("name CA")
    traj_protein.superpose(traj_protein, atom_indices=ca_indices, frame=0)

    mean_xyz = traj_protein.xyz[:, ca_indices, :].mean(axis=0, keepdims=True)
    rmsd_to_mean = np.sqrt(((traj_protein.xyz[:, ca_indices, :] - mean_xyz) ** 2).sum(-1).mean(-1))
    medoid_idx = int(np.argmin(rmsd_to_mean))

    traj_protein[medoid_idx].save_pdb(out_pdb)
    return out_pdb
