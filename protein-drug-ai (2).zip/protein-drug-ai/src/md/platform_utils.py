"""Resolve an OpenMM compute platform by name, failing loudly (rather than
silently falling back to something much slower) when the requested one
isn't available on this machine.

OpenMM's own `Platform.getPlatformByName` already raises if the name is
unknown, but its error message doesn't tell you *what is* available, which
is the first thing you want to know when e.g. "CUDA" fails on a machine
with no GPU. This wraps it with that context, and validates any
platform-specific properties (e.g. `{"Precision": "mixed"}` for CUDA)
against what the chosen platform actually supports.
"""

from __future__ import annotations

from typing import Dict, Optional, Tuple

VALID_PLATFORM_NAMES = ("Reference", "CPU", "CUDA", "OpenCL")


def list_available_platforms() -> list:
    """Names of OpenMM platforms actually usable on this machine, in the
    order OpenMM would try them (roughly fastest-to-slowest when multiple
    are available: CUDA/OpenCL > CPU > Reference).
    """
    import openmm

    return [openmm.Platform.getPlatform(i).getName() for i in range(openmm.Platform.getNumPlatforms())]


def resolve_platform(
    platform_name: str, properties: Optional[Dict[str, str]] = None
) -> Tuple["openmm.Platform", Optional[Dict[str, str]]]:  # noqa: F821
    """Look up an OpenMM Platform by name (case-insensitive), with a clear
    error listing what's actually available if it can't be found. Returns
    (platform, properties) ready to pass into `openmm.app.Simulation`.
    """
    import openmm

    normalized = {name.lower(): name for name in VALID_PLATFORM_NAMES}
    key = platform_name.strip().lower()
    if key not in normalized:
        raise ValueError(
            f"Unknown platform '{platform_name}'. Valid OpenMM platform names: {VALID_PLATFORM_NAMES}"
        )
    canonical_name = normalized[key]

    available = list_available_platforms()
    if canonical_name not in available:
        raise RuntimeError(
            f"Platform '{canonical_name}' was requested but is not available on this "
            f"machine/OpenMM build. Available platforms here: {available}. "
            f"(CUDA/OpenCL require a GPU + the matching OpenMM build; CPU and "
            f"Reference are always available.)"
        )

    platform = openmm.Platform.getPlatformByName(canonical_name)

    if properties:
        supported = set(platform.getPropertyNames())
        unsupported = set(properties) - supported
        if unsupported:
            raise ValueError(
                f"Platform '{canonical_name}' does not support propert{'y' if len(unsupported) == 1 else 'ies'} "
                f"{sorted(unsupported)}. Supported properties: {sorted(supported)}"
            )
        return platform, properties

    return platform, None
