"""End-to-end MD simulation driver built on OpenMM: energy minimization,
short NVT equilibration, and a production run with trajectory + energy
logging. Defaults are tuned to actually finish on a laptop CPU for a small
protein (used both for genuine short refinement runs and for generating
conformational-ensemble features for the ML pipeline).
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Optional

from src.md.system_builder import SystemBuildResult, build_system


@dataclass
class MDRunResult:
    minimized_pdb: str
    trajectory_dcd: Optional[str]
    log_csv: Optional[str]
    final_potential_energy_kj_mol: float


class MDSimulation:
    def __init__(
        self,
        fixed_pdb_path: str,
        solvent: str = "implicit",
        temperature_k: float = 300.0,
        friction_per_ps: float = 1.0,
        timestep_fs: float = 2.0,
        platform_name: Optional[str] = None,  # "CUDA" | "OpenCL" | "CPU" | "Reference" | None (auto)
        platform_properties: Optional[dict] = None,  # e.g. {"Precision": "mixed", "DeviceIndex": "0"}
    ):
        from openmm import LangevinMiddleIntegrator, unit
        from openmm.app import Simulation

        self.build_result: SystemBuildResult = build_system(fixed_pdb_path, solvent=solvent)
        self.temperature_k = temperature_k

        integrator = LangevinMiddleIntegrator(
            temperature_k * unit.kelvin,
            friction_per_ps / unit.picosecond,
            timestep_fs * unit.femtoseconds,
        )

        if platform_name is not None:
            # explicit choice: fail loudly if it can't be satisfied, rather
            # than silently falling back to something much slower
            from src.md.platform_utils import resolve_platform

            platform, properties = resolve_platform(platform_name, platform_properties)
            self.simulation = Simulation(
                self.build_result.topology, self.build_result.system, integrator, platform, properties
            )
            self.platform_name = platform.getName()
        else:
            # auto mode: let OpenMM pick the fastest platform actually
            # available on this machine (CUDA/OpenCL > CPU > Reference)
            self.simulation = Simulation(self.build_result.topology, self.build_result.system, integrator)
            self.platform_name = self.simulation.context.getPlatform().getName()

        self.simulation.context.setPositions(self.build_result.positions)

    def minimize(self, max_iterations: int = 1000, tolerance_kj_mol_nm: float = 10.0):
        from openmm import unit

        self.simulation.minimizeEnergy(
            maxIterations=max_iterations,
            tolerance=tolerance_kj_mol_nm * unit.kilojoule_per_mole / unit.nanometer,
        )

    def set_velocities_to_temperature(self, temperature_k: Optional[float] = None):
        self.simulation.context.setVelocitiesToTemperature(temperature_k or self.temperature_k)

    def run_steps(self, n_steps: int):
        self.simulation.step(n_steps)

    def get_potential_energy_kj_mol(self) -> float:
        from openmm import unit

        state = self.simulation.context.getState(getEnergy=True)
        return state.getPotentialEnergy().value_in_unit(unit.kilojoule_per_mole)

    def write_pdb(self, path: str):
        from openmm.app import PDBFile

        state = self.simulation.context.getState(getPositions=True)
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        with open(path, "w") as f:
            PDBFile.writeFile(self.simulation.topology, state.getPositions(), f, keepIds=True)

    def run_full_pipeline(
        self,
        out_dir: str,
        minimize_only: bool = False,
        equilibration_steps: int = 5000,  # 5000 * 2fs = 10 ps
        production_steps: int = 25000,  # 25000 * 2fs = 50 ps
        report_interval: int = 500,
        run_name: str = "run",
    ) -> MDRunResult:
        from openmm.app import DCDReporter, StateDataReporter

        out_dir_path = Path(out_dir)
        out_dir_path.mkdir(parents=True, exist_ok=True)

        self.minimize()
        minimized_pdb = str(out_dir_path / f"{run_name}_minimized.pdb")
        self.write_pdb(minimized_pdb)
        final_pe = self.get_potential_energy_kj_mol()

        if minimize_only:
            return MDRunResult(
                minimized_pdb=minimized_pdb,
                trajectory_dcd=None,
                log_csv=None,
                final_potential_energy_kj_mol=final_pe,
            )

        self.set_velocities_to_temperature()
        self.run_steps(equilibration_steps)

        trajectory_dcd = str(out_dir_path / f"{run_name}_production.dcd")
        log_csv = str(out_dir_path / f"{run_name}_log.csv")

        self.simulation.reporters.append(DCDReporter(trajectory_dcd, report_interval))
        self.simulation.reporters.append(
            StateDataReporter(
                log_csv,
                report_interval,
                step=True,
                potentialEnergy=True,
                kineticEnergy=True,
                temperature=True,
                speed=True,
            )
        )
        self.run_steps(production_steps)
        final_pe = self.get_potential_energy_kj_mol()

        final_pdb = str(out_dir_path / f"{run_name}_final.pdb")
        self.write_pdb(final_pdb)

        return MDRunResult(
            minimized_pdb=minimized_pdb,
            trajectory_dcd=trajectory_dcd,
            log_csv=log_csv,
            final_potential_energy_kj_mol=final_pe,
        )
