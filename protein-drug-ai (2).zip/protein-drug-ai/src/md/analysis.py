"""mdtraj-based trajectory analysis: the standard summary statistics used
to sanity-check an MD run and to characterize conformational flexibility.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Optional

import numpy as np


@dataclass
class TrajectoryAnalysis:
    n_frames: int
    rmsd_to_first_frame: np.ndarray  # (n_frames,) nm, CA atoms
    rmsf_per_residue: np.ndarray  # (n_residues,) nm, CA atoms
    radius_of_gyration: np.ndarray  # (n_frames,) nm
    mean_rmsd_nm: float
    mean_rg_nm: float
    dssp_codes: Optional[np.ndarray] = None  # (n_frames, n_residues) simplified 3-class SS


def analyze_trajectory(
    topology_pdb: str, trajectory_dcd: str, compute_dssp: bool = True
) -> TrajectoryAnalysis:
    import mdtraj as md

    traj = md.load(trajectory_dcd, top=topology_pdb)
    traj_protein = traj.atom_slice(traj.topology.select("protein"))

    ca_indices = traj_protein.topology.select("name CA")
    traj_protein.superpose(traj_protein, atom_indices=ca_indices, frame=0)

    rmsd = md.rmsd(traj_protein, traj_protein, frame=0, atom_indices=ca_indices)
    rmsf = md.rmsf(traj_protein, traj_protein, frame=0, atom_indices=ca_indices)
    rg = md.compute_rg(traj_protein)

    dssp = None
    if compute_dssp:
        try:
            dssp = md.compute_dssp(traj_protein, simplified=True)  # 'H','E','C' per residue per frame
        except Exception:
            dssp = None  # DSSP needs mkdssp or a compatible build; degrade gracefully

    return TrajectoryAnalysis(
        n_frames=traj_protein.n_frames,
        rmsd_to_first_frame=rmsd,
        rmsf_per_residue=rmsf,
        radius_of_gyration=rg,
        mean_rmsd_nm=float(np.mean(rmsd)),
        mean_rg_nm=float(np.mean(rg)),
        dssp_codes=dssp,
    )


def summarize(analysis: TrajectoryAnalysis) -> Dict[str, float]:
    summary = {
        "n_frames": analysis.n_frames,
        "mean_rmsd_nm": analysis.mean_rmsd_nm,
        "max_rmsd_nm": float(np.max(analysis.rmsd_to_first_frame)),
        "mean_rg_nm": analysis.mean_rg_nm,
        "rg_std_nm": float(np.std(analysis.radius_of_gyration)),
        "mean_rmsf_nm": float(np.mean(analysis.rmsf_per_residue)),
        "max_rmsf_nm": float(np.max(analysis.rmsf_per_residue)),
        "most_flexible_residue_idx": int(np.argmax(analysis.rmsf_per_residue)),
    }
    if analysis.dssp_codes is not None:
        flat = analysis.dssp_codes.flatten()
        for code, label in (("H", "helix_frac"), ("E", "sheet_frac"), ("C", "coil_frac")):
            summary[label] = float(np.mean(flat == code))
    return summary
