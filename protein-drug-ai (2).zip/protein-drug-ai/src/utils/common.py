"""Shared utilities: seeding, device selection, simple CSV/stdout logger."""

from __future__ import annotations

import csv
import os
import random
import time
from pathlib import Path
from typing import Any, Dict, Optional

import numpy as np
import torch


def set_seed(seed: int = 42) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    os.environ["PYTHONHASHSEED"] = str(seed)


def get_device(preferred: str = "auto") -> torch.device:
    if preferred != "auto":
        return torch.device(preferred)
    if torch.cuda.is_available():
        return torch.device("cuda")
    if torch.backends.mps.is_available():  # Apple Silicon
        return torch.device("mps")
    return torch.device("cpu")


class ExperimentLogger:
    """Minimal stdout + CSV metrics logger (no external dependency).

    Swap in Weights & Biases by implementing the same `log()` interface.
    """

    def __init__(self, run_dir: str | Path, name: str = "run"):
        self.run_dir = Path(run_dir)
        self.run_dir.mkdir(parents=True, exist_ok=True)
        self.csv_path = self.run_dir / "metrics.csv"
        self._fieldnames: Optional[list] = None
        self._start = time.time()
        self.name = name

    def log(self, step: int, metrics: Dict[str, Any]) -> None:
        row = {"step": step, "elapsed_sec": round(time.time() - self._start, 2), **metrics}
        write_header = not self.csv_path.exists()
        if self._fieldnames is None:
            self._fieldnames = list(row.keys())
        with open(self.csv_path, "a", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=self._fieldnames)
            if write_header:
                writer.writeheader()
            writer.writerow(row)
        msg = " | ".join(f"{k}={v}" for k, v in row.items())
        print(f"[{self.name}] {msg}")
