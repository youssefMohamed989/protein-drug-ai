"""Lightweight YAML -> dataclass-ish config loader (no framework lock-in)."""

from __future__ import annotations

import copy
from pathlib import Path
from typing import Any, Dict

import yaml


class Config(dict):
    """A dict that also supports attribute access, recursively.

    Example
    -------
    >>> cfg = Config.from_yaml("configs/protein_structure.yaml")
    >>> cfg.model.hidden_dim
    256
    """

    def __getattr__(self, name: str) -> Any:
        try:
            value = self[name]
        except KeyError as exc:
            raise AttributeError(name) from exc
        if isinstance(value, dict) and not isinstance(value, Config):
            value = Config(value)
            self[name] = value
        return value

    def __setattr__(self, name: str, value: Any) -> None:
        self[name] = value

    @classmethod
    def from_yaml(cls, path: str | Path) -> "Config":
        with open(path, "r") as f:
            raw = yaml.safe_load(f)
        return cls(_wrap(raw))

    def merge(self, overrides: Dict[str, Any]) -> "Config":
        """Return a new Config with dotted-key overrides applied.

        e.g. cfg.merge({"training.lr": 1e-4})
        """
        merged = copy.deepcopy(dict(self))
        for dotted_key, value in overrides.items():
            keys = dotted_key.split(".")
            node = merged
            for k in keys[:-1]:
                node = node.setdefault(k, {})
            node[keys[-1]] = value
        return Config(_wrap(merged))


def _wrap(obj: Any) -> Any:
    if isinstance(obj, dict):
        return {k: _wrap(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [_wrap(v) for v in obj]
    return obj
