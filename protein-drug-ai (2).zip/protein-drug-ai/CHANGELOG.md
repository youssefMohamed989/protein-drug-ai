# Changelog

All notable changes to this project are documented in this file.
Format loosely follows [Keep a Changelog](https://keepachangelog.com/).

## [Unreleased]

### Added
- `src/models/esm_backend.py`: `ESM2EmbeddingBackend`, a real pretrained
  ESM-2 (HuggingFace `transformers`) implementation of `ProteinEncoder`'s
  `embedding_backend` hook — vocab remapping, frozen-by-default, offline
  `pretrained=false` path for testing/CI without network access.
  `configs/structure_advanced_esm2.yaml` wires it into `scripts/train.py`.
- `src/md/platform_utils.py`: explicit OpenMM platform selection
  (`Reference`/`CPU`/`CUDA`/`OpenCL`) with clear errors when the requested
  platform isn't available, wired into `MDSimulation` and exposed as
  `--platform_name`/`--platform_property` on `scripts/run_md.py`.
- `tests/test_esm_backend.py`, `tests/test_platform_utils.py` (10 new
  tests; full suite now 41, all passing).
- `esm` optional dependency group in `pyproject.toml`.

## [0.2.0] - Docking, MD, and API

### Added
- `src/structure/`: backbone torsion-angle (phi/psi) prediction head, NeRF
  3D backbone reconstruction, PDB export, `AdvancedStructureModel`
  (`configs/structure_advanced.yaml`, `scripts/predict_structure.py`).
- `src/docking/`: PDBFixer/RDKit/Meeko receptor+ligand preparation,
  AutoDock Vina wrapper (`vina_runner.py`), ML-prescreen + consensus
  rescoring (`ml_rescoring.py`), `scripts/dock.py`,
  `configs/docking.yaml`.
- `src/md/`: OpenMM system builder (implicit/explicit/vacuum solvent),
  minimize/equilibrate/production simulation driver, mdtraj-based
  trajectory analysis (RMSD/RMSF/Rg/DSSP), MD -> training-data feature
  extraction (time-averaged contact maps), `scripts/run_md.py`,
  `configs/md.yaml`.
- `src/api/`: FastAPI inference server (`/health`, `/predict_structure`,
  `/score_affinity`), `scripts/serve.py`.
- `docs/docking_and_md.md`: pipeline order, the minimize-before-dock-prep
  requirement (and why), and closing-the-loop instructions.
- Packaging: `pyproject.toml` (editable install, optional dependency
  groups, console scripts `pdai-*`), `Dockerfile`, `docker-compose.yml`,
  `Makefile`, `.pre-commit-config.yaml`, `CONTRIBUTING.md`.
- Tests: `test_structure_nerf.py`, `test_docking.py`, `test_md.py`,
  `test_api.py` (31 tests total, all passing; docking/md/api tests skip
  cleanly when their optional dependencies aren't installed).

### Notes
- Meeko's docking-prep step perceives bonds by interatomic distance and
  can fail on raw/predicted structures with residual geometric strain;
  the documented pipeline runs one OpenMM minimization pass first. This
  was found and fixed during development, not a hypothetical caveat.

## [0.1.0] - Initial pipeline

### Added
- `src/data/`: protein sequence + PDB featurization, RDKit molecule graph
  featurization, `Dataset` classes, leakage-aware splitters
  (random/scaffold/protein-cluster).
- `src/models/`: BiLSTM+Transformer protein encoder (SS8 + contact-map
  heads), from-scratch GIN molecular graph network, cross-modal
  co-attention fusion model.
- `src/training/`: generic `Trainer` (AMP, early stopping, checkpointing),
  task losses/metrics.
- `src/inference/`: affinity predictor, Tanimoto-filtered virtual
  screening.
- `scripts/{train,screen,make_toy_data}.py`, three training configs,
  `.github/workflows/ci.yml`, `docs/{architecture,data_schema}.md`.
