#!/usr/bin/env python
"""CLI: rank a candidate ligand library against a target protein sequence.

Example:
    python scripts/screen.py \
        --target_fasta data/raw/target.fasta \
        --library data/raw/candidates.smi \
        --checkpoint checkpoints/fusion_affinity/best.pt \
        --config configs/fusion_affinity.yaml \
        --top_k 20
"""

import argparse
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from src.inference.screen import run_screen


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--target_fasta", type=str, required=True)
    parser.add_argument("--library", type=str, required=True, help=".smi or .csv file")
    parser.add_argument("--checkpoint", type=str, required=True)
    parser.add_argument("--config", type=str, default="configs/fusion_affinity.yaml")
    parser.add_argument("--top_k", type=int, default=20)
    parser.add_argument("--no_diversity_filter", action="store_true")
    parser.add_argument("--device", type=str, default="cpu")
    parser.add_argument("--out_csv", type=str, default="checkpoints/screening_results.csv")
    args = parser.parse_args()

    df = run_screen(
        target_fasta=args.target_fasta,
        library_path=args.library,
        checkpoint_path=args.checkpoint,
        config_path=args.config,
        top_k=args.top_k,
        apply_diversity_filter=not args.no_diversity_filter,
        device=args.device,
    )

    Path(args.out_csv).parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(args.out_csv, index=False)
    print(df.to_string(index=False))
    print(f"\nSaved full ranking to {args.out_csv}")


if __name__ == "__main__":
    main()
