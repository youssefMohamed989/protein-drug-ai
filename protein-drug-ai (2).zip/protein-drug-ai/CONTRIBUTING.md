# Contributing to ProteinDrugAI

Thanks for considering a contribution. This project spans four connected
pipelines (structure prediction, drug discovery, docking, MD) — see
`docs/architecture.md` and `docs/docking_and_md.md` before diving in if
you're not already familiar with the layout.

## Getting set up

```bash
git clone https://github.com/<you>/protein-drug-ai.git
cd protein-drug-ai
python -m venv .venv && source .venv/bin/activate
make install-all       # editable install + every optional dependency group
make toy-data           # generates synthetic data so everything runs offline
make test                # should be all green before you start
```

If you only want to work on one pipeline, install a narrower dependency
group instead of `all`: `pip install -e ".[chem]"` (drug discovery),
`".[docking]"`, `".[md]"`, or `".[api]"` — see `pyproject.toml`.

## Before opening a PR

```bash
make format     # black + isort
make lint         # flake8 (errors only) + format check
make test          # full pytest suite
```

Tests for optional-dependency modules (`docking`, `md`, `api`) use
`pytest.importorskip`, so they skip cleanly rather than fail if you don't
have those extras installed — but if you're touching that code, please
install the relevant extra and confirm the tests actually run, not just
skip.

## Adding a new task/pipeline

The repo's pattern for adding a new trainable task (see `scripts/train.py`):
1. Add a `Dataset` in `src/data/datasets.py` (+ a collate function if the
   batch shape is new).
2. Add the model in `src/models/` or a new top-level `src/<area>/`.
3. Add a `loss_fn`/`metrics_fn` pair (see `src/training/losses_metrics.py`
   for the expected signatures).
4. Add a `forward_fn` adapter in `src/training/task_adapters.py`.
5. Add a `build_<task>()` function and register it in `BUILDERS` in
   `scripts/train.py`.
6. Add a matching `configs/<task>.yaml`.
7. Add toy-data generation in `scripts/make_toy_data.py` so `make test`
   and CI can exercise it without real data.

This keeps one generic `Trainer` (`src/training/trainer.py`) driving every
task instead of near-duplicate training loops.

## Commit style

Small, focused commits. Reference the module you're changing in the
subject line (e.g. `docking: fix box padding on single-atom ligands`).

## Reporting issues

Use the issue templates in `.github/ISSUE_TEMPLATE/`. For bugs, include:
your Python/OS version, which optional dependency groups are installed,
and — if it's a docking/MD issue — whether the input structure has been
through the required minimization step (see `docs/docking_and_md.md`).
