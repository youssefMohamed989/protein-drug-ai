---
name: Feature request
about: Suggest an addition or improvement
title: "[FEATURE] "
labels: enhancement
---

**What problem would this solve?**
A clear description of the use case or gap.

**Proposed approach**
If you have one in mind — which module/pipeline it touches, roughly how it
would fit the existing pattern (see `CONTRIBUTING.md` for the "adding a
new task" checklist if it's a new trainable task).

**Alternatives considered**
Any other approaches you thought about.
