---
name: Bug report
about: Something isn't working as expected
title: "[BUG] "
labels: bug
---

**Which pipeline?**
- [ ] Protein structure (SS8/contact/torsion)
- [ ] Drug discovery (GNN affinity)
- [ ] Fusion / virtual screening
- [ ] Docking
- [ ] Molecular dynamics
- [ ] API server
- [ ] Other / not sure

**Describe the bug**
A clear description of what went wrong.

**To reproduce**
Exact command(s) and, if relevant, a minimal input file that triggers it.

```bash
python scripts/...
```

**Expected behavior**
What you expected to happen instead.

**Environment**
- OS:
- Python version:
- Installed extras (`pip show protein-drug-ai` or which of `chem`/`docking`/`md`/`api` you installed):
- GPU/CPU:

**For docking/MD issues specifically**
- [ ] The input structure has already been through one MD minimization pass (see `docs/docking_and_md.md`)
- [ ] The input structure is experimental (X-ray/cryo-EM), not model-predicted

**Logs / traceback**
```
paste here
```
