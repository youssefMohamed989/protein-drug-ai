## What does this change?

<!-- Brief description -->

## Which pipeline(s)?
- [ ] Protein structure
- [ ] Drug discovery
- [ ] Fusion / screening
- [ ] Docking
- [ ] Molecular dynamics
- [ ] API
- [ ] Infra / CI / packaging

## Checklist
- [ ] `make format` run
- [ ] `make lint` passes
- [ ] `make test` passes locally (including any new tests for this change)
- [ ] Updated `CHANGELOG.md` if this is user-facing
- [ ] Updated relevant `docs/*.md` if behavior/pipeline order changed

## Testing performed

<!-- What did you actually run to verify this works? Commands + output,
     not just "should work". -->
