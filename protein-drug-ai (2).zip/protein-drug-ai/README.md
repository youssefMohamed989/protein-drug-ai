# ProteinDrugAI

[![CI](https://github.com/OWNER/protein-drug-ai/actions/workflows/ci.yml/badge.svg)](https://github.com/OWNER/protein-drug-ai/actions/workflows/ci.yml)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](LICENSE)
[![Python 3.10+](https://img.shields.io/badge/python-3.10%2B-blue.svg)](pyproject.toml)
[![Code style: black](https://img.shields.io/badge/code%20style-black-000000.svg)](https://github.com/psf/black)

*(Replace `OWNER` in the CI badge URL with your GitHub username/org once pushed.)*


An end-to-end, research-grade machine learning pipeline that combines
**protein structure prediction** (sequence → secondary structure + contact
map + 3D backbone via torsion angles), **drug discovery** (molecular graph
→ binding-affinity / bioactivity prediction), **molecular docking**
(AutoDock Vina, ML-pre-screened), and **molecular dynamics** (OpenMM
minimization/equilibration/production + trajectory analysis) into one
pipeline you can train, run, and extend end to end.

This is not a reimplementation of AlphaFold — it is a realistic, extensible
scaffold you can train on public data (or your own), extend, and deploy,
built the way a research engineering team would structure it.

**See [`docs/pipeline_overview.md`](docs/pipeline_overview.md) for a short,
stage-by-stage description of the full pipeline** (structure → screening →
docking → MD → back into training).

```
                         ┌─ secondary structure (Q8)
protein sequence ──▶ ProteinEncoder ──┼─ residue contact map
                                       ├─ phi/psi torsion angles ──▶ NeRF ──▶ 3D backbone PDB
                                       └─ 256-d protein embedding             │
                                                    │                  PDBFixer + OpenMM
SMILES ──▶ MoleculeGraph ──▶ GNN ──▶ 256-d molecule embedding          minimization
                                                    │                         │
                              protein embedding ⊕ molecule embedding   AutoDock Vina
                                                    │                    docking
                                    Affinity/Activity MLP head                │
                                                    │                  ranked poses
                                          pKd / pIC50 / binding prob.  + consensus score
                                                    │                         │
                                        ML pre-screen (top-K) ────────────────┘
                                        for docking at library scale
```

## Features

- **Protein Structure Module** (`src/models/protein_encoder.py`,
  `src/structure/`)
  - BiLSTM + multi-head self-attention encoder over amino-acid sequences
  - Auxiliary heads: 8-class secondary structure (Q8), residue-residue
    contact map (binary, L×L), and **backbone torsion angles (phi/psi)**
    regressed via their (sin, cos) representation
  - **3D structure export**: predicted torsion angles are reconstructed
    into an actual N/CA/C/O backbone trace via NeRF (Natural Extension
    Reference Frame) — exact idealized bond geometry, pure NumPy, written
    straight to a PDB file (`scripts/predict_structure.py`)
  - Supports pretrained embedding injection (ESM-2 style) via a pluggable
    `embedding_backend` interface — falls back to a learned embedding table
    when no external embedder is available. `src/models/esm_backend.py`
    implements this with a real HuggingFace `transformers` ESM-2 model
    (`configs/structure_advanced_esm2.yaml`); frozen by default, with an
    offline random-init path for testing without Hub access
- **Drug Discovery Module** (`src/models/molecule_gnn.py`)
  - SMILES → molecular graph (via RDKit) → Graph Isomorphism Network (GIN)
  - Predicts binding affinity (regression, pKd/pIC50) and activity
    (classification, active/inactive) jointly
- **Cross-Modal Fusion** (`src/models/fusion.py`)
  - Co-attention between protein residues and molecule atoms
  - Late-fusion MLP head for final affinity/activity prediction
- **Molecular Docking** (`src/docking/`, `scripts/dock.py`)
  - Receptor prep (PDBFixer) and ligand prep (RDKit 3D embedding +
    Meeko PDBQT) feeding **real AutoDock Vina** docking runs
  - ML pre-screen: the fusion affinity model ranks a whole candidate
    library first, so expensive physics-based docking only runs on the
    most promising top-K — the standard way ML and docking are combined
    at library scale
  - Consensus rescoring: z-scored combination of the ML prediction and
    the Vina binding free energy into one ranking
- **Molecular Dynamics** (`src/md/`, `scripts/run_md.py`)
  - OpenMM-based minimization, NVT equilibration, and production runs
    (implicit-solvent GBn2 by default for CPU-friendly speed; explicit
    TIP3P solvation available for production-quality runs)
  - mdtraj-based analysis: RMSD, per-residue RMSF, radius of gyration,
    simplified DSSP secondary-structure fractions over the trajectory
  - **Closes the loop with the ML pipeline**: MD trajectories can be
    turned into time-averaged contact maps in the exact CSV format the
    structure-prediction dataset reads — real physics-derived labels to
    fine-tune on, not just static single-frame targets
  - Also the required relaxation step before docking prep: predicted (or
    otherwise strained) structures need one minimization pass before
    Meeko's distance-based bond perception can process them (see
    `docs/docking_and_md.md` for why — we hit and debugged this directly)
  - Explicit GPU platform selection (`src/md/platform_utils.py`,
    `--platform_name CUDA`) with clear errors when the requested platform
    isn't available, rather than a silent slow fallback
- **Virtual Screening** (`src/inference/screen.py`)
  - Ranks a library of candidate molecules (SDF/CSV/SMILES) against one or
    more target proteins purely from learned embeddings (no docking engine
    required), with optional Tanimoto-similarity re-ranking as a sanity
    filter
- **Training infrastructure**
  - Config-driven (`configs/*.yaml`) via a small dataclass-based config
    loader — no framework lock-in
  - Mixed precision, gradient accumulation, early stopping, checkpointing
  - Experiment tracking hooks (stdout/CSV logger; optional Weights & Biases)
  - Reproducible splits: random, scaffold split (Bemis–Murcko), and
    protein-family cluster split to avoid data leakage
- **Data pipeline**
  - Parsers for FASTA, PDB (secondary structure + contact map extraction
    via Biopython), and SMILES/CSV bioactivity tables (ChEMBL-style)
  - `Dataset`/`DataLoader` classes with on-the-fly featurization and caching
- **Testing & CI**
  - `pytest` unit tests for data parsing, featurization, and model
    forward-passes (shape checks) — no network/GPU required
  - GitHub Actions workflow running lint + tests on every push

## Repository layout

```
protein-drug-ai/
├── src/
│   ├── data/            # parsers, datasets, featurizers, splitters
│   ├── models/           # protein encoder, molecule GNN, fusion, heads
│   ├── structure/         # torsion head, NeRF 3D reconstruction, PDB export
│   ├── docking/            # receptor/ligand prep, AutoDock Vina, ML rescoring
│   ├── md/                  # OpenMM simulation, mdtraj analysis, feature extraction
│   ├── api/                  # FastAPI inference server
│   ├── training/               # trainer loop, losses, metrics, callbacks
│   ├── inference/               # prediction + virtual screening
│   └── utils/                    # config loader, logging, seeding
├── configs/                # YAML experiment configs
├── scripts/                # CLIs (train, predict_structure, dock, run_md, serve, evaluate, screen)
├── tests/                  # pytest unit tests (31, all optional-dep modules skip cleanly)
├── notebooks/              # exploratory analysis
├── data/                   # raw/ and processed/ (gitignored, README stubs)
├── checkpoints/            # saved model weights (gitignored)
├── docs/                   # architecture.md, data_schema.md, docking_and_md.md
├── .github/                 # CI workflow, issue/PR templates
├── pyproject.toml           # packaging + tool configs (black/isort/pytest)
├── Dockerfile, docker-compose.yml
└── Makefile                  # install/test/lint/format/train/serve targets
```

## Quickstart

```bash
git clone https://github.com/<you>/protein-drug-ai.git
cd protein-drug-ai
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt

# 1. Prepare toy data (bundled samples so the pipeline runs end-to-end offline)
python scripts/make_toy_data.py

# 2. Train the protein structure encoder
python scripts/train.py --config configs/protein_structure.yaml

# 3. Train the molecule affinity GNN
python scripts/train.py --config configs/drug_affinity.yaml

# 4. Train the fused affinity model (uses both pretrained encoders)
python scripts/train.py --config configs/fusion_affinity.yaml

# 4b. (optional) Train the advanced structure model with 3D torsion prediction
python scripts/train.py --config configs/structure_advanced.yaml

# 5. Run virtual screening: rank a ligand library against a target sequence
python scripts/screen.py \
    --target_fasta data/raw/target.fasta \
    --library data/raw/candidates.smi \
    --checkpoint checkpoints/fusion_affinity/best.pt \
    --top_k 20

# 6. Predict a 3D structure and export a PDB
python scripts/predict_structure.py \
    --sequence MKTAYIAKQRQISFVKSHFSRQLEERLGLIEVQAPILSRVGDGTQDNLSGAEKAVQVKV \
    --checkpoint checkpoints/structure_advanced/best.pt \
    --out_pdb checkpoints/predicted_structure.pdb

# 7. Relax the predicted structure with MD before docking (required — see
#    docs/docking_and_md.md for why)
python scripts/run_md.py --pdb checkpoints/predicted_structure_fixed.pdb \
    --out_dir checkpoints/md_run --minimize_only

# 8. Dock a candidate library against it: ML pre-screen -> AutoDock Vina ->
#    consensus rescoring
python scripts/dock.py \
    --receptor_pdb checkpoints/md_run/run_minimized.pdb \
    --library data/raw/candidates.smi \
    --target_fasta data/raw/target.fasta \
    --ml_checkpoint checkpoints/fusion_affinity/best.pt \
    --prescreen_top_k 20
```

See `docs/docking_and_md.md` for the full docking/MD pipeline, including
why the minimization step before docking is required (not optional) and
how to feed MD trajectories back into the structure-prediction training
data.

## Installation options

```bash
pip install -e .                # core (structure/drug-discovery ML only)
pip install -e ".[chem]"         # + RDKit (needed for anything molecule-related)
pip install -e ".[docking]"       # + AutoDock Vina, Meeko, PDBFixer
pip install -e ".[md]"             # + OpenMM, PDBFixer, mdtraj
pip install -e ".[api]"             # + FastAPI, uvicorn
pip install -e ".[esm]"              # + transformers, for the pretrained ESM-2 backend
pip install -e ".[all]"               # everything
```

This also installs console scripts: `pdai-train`, `pdai-predict-structure`,
`pdai-dock`, `pdai-run-md`, `pdai-screen` — equivalent to
`python scripts/<name>.py`.

Or use `make`:
```bash
make install-all   # editable install, every extra
make toy-data        # generate synthetic data
make test              # run the full test suite
make format              # black + isort
make lint                  # flake8 + format check (what CI runs)
```

## REST API

A FastAPI server exposes structure prediction and affinity scoring over
HTTP, for integrating this pipeline into a larger service:

```bash
python scripts/serve.py --port 8000
# or: make serve
```

```bash
curl -X POST http://localhost:8000/predict_structure \
    -H "Content-Type: application/json" \
    -d '{"sequence": "ACDEFGHIKLMNPQRSTVWY"}'

curl -X POST http://localhost:8000/score_affinity \
    -H "Content-Type: application/json" \
    -d '{"sequence": "ACDEFGHIKLMNPQRSTVWY", "smiles": ["CC(=O)OC1=CC=CC=C1C(=O)O"]}'
```

`GET /health` reports which model checkpoints are currently cached in
memory. Endpoints return `503` with a clear message if the requested
checkpoint doesn't exist yet (train one first). See `src/api/server.py`
for the full schema (Pydantic request/response models).

## Docker

```bash
docker build -t protein-drug-ai .
docker run --rm -p 8000:8000 \
    -v $(pwd)/checkpoints:/app/checkpoints \
    protein-drug-ai
# or: docker compose up --build
```

The default `CMD` launches the API server; override it to run training,
docking, or MD scripts inside the container instead (see the comment in
`Dockerfile`).

## Evaluating a trained model against naive baselines

```bash
python scripts/evaluate.py --task fusion_affinity \
    --checkpoint checkpoints/fusion_affinity/best.pt \
    --config configs/fusion_affinity.yaml \
    --test_csv data/processed/pairs_test.csv
```

Reports model MAE/RMSE/Pearson-r/accuracy/ROC-AUC against a mean-predictor
and majority-class baseline. A model that doesn't clear these baselines by
a solid margin isn't learning anything useful yet — treat this as the
minimum bar for trusting a checkpoint, not a benchmark to brag about. (On
a 1-epoch smoke-train over the bundled 27-example toy test set, the model
does *not* yet beat the mean-predictor baseline — exactly the kind of
honest signal this script exists to surface. Train longer / on real data
before drawing conclusions.)

## Development

See `CONTRIBUTING.md` for the full guide, including the pattern for
adding a new trainable task. Quick reference: `make format`, `make lint`,
`make test` before opening a PR; pre-commit hooks available via
`.pre-commit-config.yaml` (`pre-commit install`).

## Data sources this pipeline is designed to consume

| Modality | Format | Suggested public source |
|---|---|---|
| Protein sequence + structure | FASTA / PDB | RCSB PDB, CATH, SCOPe |
| Secondary structure labels | DSSP-derived Q8/Q3 | PDB + `mkdssp` |
| Bioactivity (affinity/activity) | CSV (SMILES, target, pKd/pIC50, label) | ChEMBL, BindingDB, PDBbind |

None of these are downloaded automatically (no network access assumed at
run time); `scripts/make_toy_data.py` generates small synthetic-but-valid
samples so every command above runs immediately. Swap in real data by
matching the same CSV/FASTA schema documented in `docs/data_schema.md`.

## Model details

See `docs/architecture.md` for full math and design rationale, and
`docs/data_schema.md` for exact file formats expected by each `Dataset`.

## License

MIT — see `LICENSE`.
